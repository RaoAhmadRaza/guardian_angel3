
import React, { useState, useCallback } from 'react';
import { ExerciseType } from './types';
import HubScreen from './screens/HubScreen';
import ExerciseScreen from './screens/ExerciseScreen';
import CompletionScreen from './screens/CompletionScreen';

type Screen = 'HUB' | 'EXERCISE' | 'COMPLETION';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('HUB');
  const [activeExercise, setActiveExercise] = useState<ExerciseType | null>(null);

  const startExercise = useCallback((type: ExerciseType) => {
    setActiveExercise(type);
    setCurrentScreen('EXERCISE');
  }, []);

  const finishExercise = useCallback(() => {
    setCurrentScreen('COMPLETION');
  }, []);

  const goBackToHub = useCallback(() => {
    setActiveExercise(null);
    setCurrentScreen('HUB');
  }, []);

  const tryAnother = useCallback(() => {
    goBackToHub();
  }, [goBackToHub]);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col max-w-md mx-auto relative shadow-2xl">
      {currentScreen === 'HUB' && (
        <HubScreen onSelectExercise={startExercise} />
      )}
      
      {currentScreen === 'EXERCISE' && activeExercise && (
        <ExerciseScreen 
          exerciseId={activeExercise} 
          onBack={goBackToHub} 
          onFinish={finishExercise}
        />
      )}

      {currentScreen === 'COMPLETION' && (
        <CompletionScreen 
          onDone={goBackToHub} 
          onTryAnother={tryAnother} 
        />
      )}
    </div>
  );
};

export default App;
