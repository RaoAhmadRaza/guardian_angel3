
export enum ExerciseType {
  MEMORY_RECALL = 'MEMORY_RECALL',
  PATTERN_MATCH = 'PATTERN_MATCH',
  WORD_ASSOCIATION = 'WORD_ASSOCIATION',
  EMOTIONAL_REFLECTION = 'EMOTIONAL_REFLECTION',
  FOCUS_BREATHING = 'FOCUS_BREATHING'
}

export interface ExerciseData {
  id: ExerciseType;
  title: string;
  description: string;
  goal: string;
  icon: string;
  instruction: string;
  difficulty: 1 | 2 | 3;
  duration: string;
  themeColor: string; // Tailwind class for background
  accentColor: string; // Tailwind class for text/icons
}

export interface CompletionLog {
  exerciseId: ExerciseType;
  timestamp: number;
}
