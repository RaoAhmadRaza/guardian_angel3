
import React, { useState } from 'react';
import { ExerciseType } from '../types';
import { EXERCISES } from '../constants';
import { ChevronLeft, X } from 'lucide-react';
import MemoryRecall from '../components/exercises/MemoryRecall';
import PatternMatch from '../components/exercises/PatternMatch';
import WordAssociation from '../components/exercises/WordAssociation';
import EmotionalReflection from '../components/exercises/EmotionalReflection';
import FocusBreathing from '../components/exercises/FocusBreathing';

interface ExerciseScreenProps {
  exerciseId: ExerciseType;
  onBack: () => void;
  onFinish: () => void;
}

const ExerciseScreen: React.FC<ExerciseScreenProps> = ({ exerciseId, onBack, onFinish }) => {
  const [started, setStarted] = useState(false);
  const exercise = EXERCISES.find(ex => ex.id === exerciseId)!;

  const isArcadeMode = started && (exerciseId === ExerciseType.PATTERN_MATCH || exerciseId === ExerciseType.FOCUS_BREATHING);

  const renderExerciseContent = () => {
    switch (exerciseId) {
      case ExerciseType.MEMORY_RECALL:
        return <MemoryRecall onComplete={onFinish} active={started} />;
      case ExerciseType.PATTERN_MATCH:
        return <PatternMatch onComplete={onFinish} active={started} onBack={onBack} />;
      case ExerciseType.WORD_ASSOCIATION:
        return <WordAssociation onComplete={onFinish} active={started} />;
      case ExerciseType.EMOTIONAL_REFLECTION:
        return <EmotionalReflection onComplete={onFinish} active={started} />;
      case ExerciseType.FOCUS_BREATHING:
        return <FocusBreathing onComplete={onFinish} active={started} onBack={onBack} />;
      default:
        return null;
    }
  };

  return (
    <div className={`flex flex-col flex-1 h-screen overflow-hidden ${isArcadeMode ? 'bg-[#FCFAF7]' : 'bg-white'}`}>
      {/* Standard Top Bar - Elegant & Senior Friendly */}
      {!isArcadeMode && (
        <header className="px-8 py-6 flex items-center justify-between border-b border-stone-100 shrink-0 bg-white z-20">
          <button onClick={onBack} className="p-2 -ml-2 text-stone-400 hover:text-stone-800 transition-colors">
            <ChevronLeft size={32} />
          </button>
          <h2 className="font-serif-premium text-2xl text-stone-800 italic">{exercise.title}</h2>
          <div className="w-10"></div>
        </header>
      )}

      {/* Instruction Card - Large & Clear */}
      {!started && (
        <div className="flex-1 flex flex-col justify-center px-10 py-10 animate-in fade-in duration-700">
          <div className="bg-stone-50 p-12 rounded-[48px] border-2 border-stone-100 mb-12 flex flex-col items-center">
            <div className="text-8xl mb-10">{exercise.icon}</div>
            <p className="font-serif-premium text-3xl text-stone-800 text-center leading-relaxed italic">
              {exercise.instruction}
            </p>
          </div>
          <button
            onClick={() => setStarted(true)}
            className="w-full py-6 bg-stone-800 text-white rounded-[32px] text-2xl font-bold shadow-2xl hover:bg-stone-700 active:scale-[0.98] transition-all"
          >
            Start
          </button>
        </div>
      )}

      {/* Active Exercise Area */}
      {started && (
        <div className="flex-1 flex flex-col relative">
          <div className={`flex-1 ${isArcadeMode ? '' : 'p-0'} flex flex-col items-center justify-center`}>
            {renderExerciseContent()}
          </div>
          
          {/* Subtle Exit for Reflection/Association */}
          {!isArcadeMode && (
            <div className="h-24 bg-white flex items-center justify-center shrink-0 border-t border-stone-50">
               {exerciseId === ExerciseType.FOCUS_BREATHING ? null : (
                  <button 
                    onClick={onFinish}
                    className="px-10 py-3 text-stone-400 font-bold uppercase tracking-widest text-xs hover:text-stone-800"
                  >
                    Skip to Finish
                  </button>
               )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ExerciseScreen;
