
import React from 'react';
import { Trophy, Timer, Target, Flame, ChevronRight } from 'lucide-react';

interface CompletionScreenProps {
  onDone: () => void;
  onTryAnother: () => void;
}

const CompletionScreen: React.FC<CompletionScreenProps> = ({ onDone, onTryAnother }) => {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-10 bg-[#FCFAF7] relative overflow-hidden animate-in fade-in duration-1000">
      
      {/* Background Calmness */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="absolute top-[20%] left-[10%] w-64 h-64 bg-stone-200 rounded-full blur-[100px]" />
        <div className="absolute bottom-[20%] right-[10%] w-80 h-80 bg-stone-200 rounded-full blur-[120px]" />
      </div>

      {/* Hero Section: Refined Trophy */}
      <div className="relative mb-16">
        <div className="relative z-10 w-40 h-40 bg-stone-800 rounded-full flex items-center justify-center shadow-2xl border-4 border-stone-700 animate-in zoom-in duration-1000">
          <Trophy size={80} className="text-[#E5DACE]" />
        </div>
      </div>

      {/* Celebration Text */}
      <div className="text-center mb-16 z-10">
        <h2 className="font-serif-premium text-5xl text-stone-900 mb-4 italic">Wonderful work</h2>
        <p className="text-xl font-bold text-stone-400 uppercase tracking-[0.3em]">Activity Complete</p>
      </div>

      {/* Stats - Simplified & Clear */}
      <div className="grid grid-cols-2 gap-6 w-full mb-16 z-10 max-w-sm">
        <div className="bg-white border-2 border-stone-100 p-8 rounded-[40px] flex flex-col items-center justify-center shadow-sm">
          <Timer size={24} className="text-stone-400 mb-4" />
          <span className="text-2xl font-serif-premium italic text-stone-800">Relaxed</span>
          <span className="text-xs font-bold text-stone-400 uppercase tracking-widest mt-1">Pace</span>
        </div>
        <div className="bg-white border-2 border-stone-100 p-8 rounded-[40px] flex flex-col items-center justify-center shadow-sm">
          <Target size={24} className="text-stone-400 mb-4" />
          <span className="text-2xl font-serif-premium italic text-stone-800">Perfect</span>
          <span className="text-xs font-bold text-stone-400 uppercase tracking-widest mt-1">Focus</span>
        </div>
      </div>

      {/* Action Buttons - High Contrast */}
      <div className="w-full space-y-6 z-10 max-w-sm">
        <button
          onClick={onDone}
          className="w-full py-6 bg-stone-800 text-white rounded-[32px] text-2xl font-bold shadow-2xl hover:bg-stone-700 active:scale-[0.98] transition-all flex items-center justify-center gap-3"
        >
          Return Home <ChevronRight size={28} />
        </button>
        
        <button
          onClick={onTryAnother}
          className="w-full py-5 bg-white text-stone-600 rounded-[32px] text-lg font-bold border-2 border-stone-100 hover:border-stone-400 active:scale-[0.98] transition-all"
        >
          Do another exercise
        </button>
      </div>

      <p className="mt-12 text-xs font-bold text-stone-300 uppercase tracking-[0.5em]">Guardian Angel</p>
    </div>
  );
};

export default CompletionScreen;
