
import React, { useState } from 'react';
import { EXERCISES } from '../constants';
import { ExerciseType } from '../types';
import { Info, Brain, Flame, Play, Sun } from 'lucide-react';

interface HubScreenProps {
  onSelectExercise: (type: ExerciseType) => void;
}

const HubScreen: React.FC<HubScreenProps> = ({ onSelectExercise }) => {
  const [showInfo, setShowInfo] = useState(false);

  return (
    <div className="flex flex-col flex-1 pb-10 bg-[#FCFAF7]">
      {/* Top Navigation - Calm & Clear */}
      <header className="px-8 py-8 flex items-center justify-between sticky top-0 bg-[#FCFAF7]/90 backdrop-blur-md z-20 border-b border-stone-100">
        <div className="flex flex-col">
          <h1 className="font-serif-premium text-3xl text-stone-800 italic">Guardian Angel</h1>
          <p className="text-xs font-bold text-stone-400 uppercase tracking-[0.2em]">Daily Wellness Center</p>
        </div>
        <button 
          onClick={() => setShowInfo(true)}
          className="w-12 h-12 flex items-center justify-center rounded-full bg-stone-100 text-stone-600 hover:bg-stone-200 transition-colors"
          aria-label="Information"
        >
          <Info size={24} />
        </button>
      </header>

      <div className="px-8 space-y-10 overflow-y-auto pt-4">
        {/* Daily Highlight Card - Simplified & Elegant */}
        <section className="animate-in fade-in duration-1000">
          <div className="relative overflow-hidden rounded-[40px] bg-stone-800 p-10 shadow-2xl">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <Sun size={120} className="text-white" />
            </div>
            
            <div className="relative z-10">
              <span className="text-stone-400 font-bold text-xs uppercase tracking-widest mb-2 block">Featured Activity</span>
              <h2 className="font-serif-premium text-3xl text-white mb-6 italic">Memory Recall</h2>
              <p className="text-stone-300 text-lg mb-8 leading-relaxed max-w-[240px]">
                A gentle way to sharpen your focus this morning.
              </p>
              
              <button 
                onClick={() => onSelectExercise(ExerciseType.MEMORY_RECALL)}
                className="bg-[#E5DACE] text-stone-900 px-10 py-5 rounded-3xl font-bold text-xl flex items-center gap-3 hover:bg-white active:scale-95 transition-all shadow-xl"
              >
                <Play size={24} className="fill-current" />
                Begin Now
              </button>
            </div>
          </div>
        </section>

        {/* Simplified Exercise List - Large Targets */}
        <section className="pb-10">
          <h2 className="text-sm font-black text-stone-400 uppercase tracking-widest mb-6">Explore Activities</h2>
          <div className="flex flex-col gap-6">
            {EXERCISES.map((ex, idx) => (
              <button
                key={ex.id}
                onClick={() => onSelectExercise(ex.id)}
                className="flex items-center p-6 rounded-[32px] bg-white border border-stone-200 hover:border-stone-400 hover:shadow-md transition-all group text-left"
              >
                <div className="w-20 h-20 rounded-2xl bg-stone-50 flex items-center justify-center text-5xl mr-6 group-hover:scale-110 transition-transform duration-500">
                  {ex.icon}
                </div>
                <div className="flex-1">
                  <h3 className="font-serif-premium text-2xl text-stone-800 leading-tight mb-1 italic">{ex.title}</h3>
                  <p className="text-stone-500 text-base">{ex.duration} • Gentle Focus</p>
                </div>
                <div className="text-stone-300 group-hover:text-stone-600 transition-colors ml-4">
                   <Play size={24} />
                </div>
              </button>
            ))}
          </div>
        </section>
      </div>

      {/* Simplified Info Modal */}
      {showInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-8 bg-stone-900/40 backdrop-blur-sm animate-in fade-in duration-500">
          <div className="bg-white rounded-[40px] p-10 max-w-sm w-full shadow-2xl animate-in zoom-in duration-300">
            <h3 className="font-serif-premium text-3xl text-center mb-6 italic">Welcome</h3>
            <p className="text-stone-600 text-lg text-center leading-relaxed mb-8">
              Guardian Angel is designed for peaceful mental exercise. There are no timers, no scores, and no rush.
            </p>
            <button
              onClick={() => setShowInfo(false)}
              className="w-full py-5 bg-stone-800 text-white rounded-3xl font-bold text-lg hover:bg-stone-700 transition-colors shadow-lg"
            >
              Continue
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default HubScreen;
