
import { ExerciseType, ExerciseData } from './types';

export const EXERCISES: ExerciseData[] = [
  {
    id: ExerciseType.MEMORY_RECALL,
    title: 'Memory Recall',
    description: 'Gently remember simple details.',
    goal: 'Short-term memory retention',
    icon: '🧠',
    instruction: 'Take a moment to look at these items. In a few seconds, they will disappear, and you can tell me which ones you remember.',
    difficulty: 2,
    duration: '3 min',
    themeColor: 'bg-blue-50',
    accentColor: 'text-blue-600'
  },
  {
    id: ExerciseType.PATTERN_MATCH,
    title: 'Pattern Match',
    description: 'Spot visual patterns.',
    goal: 'Visual processing + focus',
    icon: '🧩',
    instruction: 'Look at the group of shapes below. One of them is slightly different from the others. Can you find it?',
    difficulty: 2,
    duration: '2 min',
    themeColor: 'bg-purple-50',
    accentColor: 'text-purple-600'
  },
  {
    id: ExerciseType.WORD_ASSOCIATION,
    title: 'Word Association',
    description: 'Think of related words.',
    goal: 'Language + cognition',
    icon: '💬',
    instruction: 'I will show you a word. Simply choose the word that feels most related to it for you. There are no wrong answers.',
    difficulty: 1,
    duration: '2 min',
    themeColor: 'bg-amber-50',
    accentColor: 'text-amber-600'
  },
  {
    id: ExerciseType.EMOTIONAL_REFLECTION,
    title: 'Emotional Reflection',
    description: 'Notice and name feelings.',
    goal: 'Emotional awareness',
    icon: '🌿',
    instruction: 'Take a quiet moment to check in with yourself. How are you feeling right now?',
    difficulty: 1,
    duration: '1 min',
    themeColor: 'bg-green-50',
    accentColor: 'text-green-600'
  },
  {
    id: ExerciseType.FOCUS_BREATHING,
    title: 'Focus Breathing',
    description: 'Combine breath with thought.',
    goal: 'Mental clarity',
    icon: '🌬️',
    instruction: 'Follow the circle as it expands and contracts. Breathe in as it grows, and out as it shrinks.',
    difficulty: 1,
    duration: '3 min',
    themeColor: 'bg-rose-50',
    accentColor: 'text-rose-600'
  }
];
