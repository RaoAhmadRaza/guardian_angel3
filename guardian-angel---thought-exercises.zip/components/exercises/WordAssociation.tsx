
import React, { useState, useEffect } from 'react';
import { getAIWordAssociation } from '../../services/geminiService';

const BASE_WORDS = [
  { word: 'Morning', theme: 'bg-[#FFF9F2]' },
  { word: 'Garden', theme: 'bg-[#F2F9F2]' },
  { word: 'Summer', theme: 'bg-[#FFFBF0]' },
  { word: 'Friendship', theme: 'bg-[#FFF2F6]' },
  { word: 'Music', theme: 'bg-[#F2F2FF]' },
  { word: 'Travel', theme: 'bg-[#F2F9FF]' },
];

interface WordAssociationProps {
  onComplete: () => void;
  active: boolean;
}

const WordAssociation: React.FC<WordAssociationProps> = ({ onComplete, active }) => {
  const [currentBase, setCurrentBase] = useState(BASE_WORDS[0]);
  const [options, setOptions] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<string | null>(null);

  useEffect(() => {
    if (active) {
      const fetchOptions = async () => {
        const base = BASE_WORDS[Math.floor(Math.random() * BASE_WORDS.length)];
        setCurrentBase(base);
        const aiOptions = await getAIWordAssociation(base.word);
        setOptions(aiOptions);
        setLoading(false);
      };
      fetchOptions();
    }
  }, [active]);

  const handleSelect = (opt: string) => {
    setSelected(opt);
    setTimeout(onComplete, 2500);
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-12">
        <div className="w-16 h-16 border-4 border-stone-200 border-t-stone-800 rounded-full animate-spin mb-6"></div>
        <p className="text-stone-400 font-bold text-lg uppercase tracking-widest">Preparing Exercise...</p>
      </div>
    );
  }

  return (
    <div className={`w-full h-full flex flex-col items-center justify-center relative overflow-hidden transition-all duration-1000 ${currentBase.theme}`}>
      
      {/* Calm, Mostly Static Background */}
      <div className="absolute inset-0 z-0 opacity-40">
        <div className="absolute top-[10%] left-[10%] w-[80%] h-[80%] bg-white rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 w-full flex flex-col items-center px-8">
        <div className="mb-16 text-center animate-in fade-in slide-in-from-top-4 duration-1000">
          <span className="text-stone-400 uppercase tracking-[0.3em] font-bold text-xs mb-4 block">Reflection</span>
          <h3 className="font-serif-premium text-6xl md:text-7xl text-stone-800 italic">
            {currentBase.word}
          </h3>
          <p className={`mt-8 text-stone-500 text-xl transition-opacity duration-500 ${selected ? 'opacity-0' : 'opacity-100'}`}>
            What word feels right to you?
          </p>
        </div>

        {/* Anchored Choice Tiles - Large & Legible */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-md">
          {options.map((opt, i) => {
            const isSelected = selected === opt;
            const isDimmed = selected !== null && !isSelected;
            
            return (
              <button
                key={i}
                onClick={() => handleSelect(opt)}
                disabled={selected !== null}
                className={`
                  p-10 rounded-[32px] text-2xl font-bold transition-all duration-700
                  border-2 shadow-sm flex items-center justify-center
                  ${isSelected ? 'bg-stone-800 text-white border-stone-800 scale-105 shadow-2xl z-20' : 
                    isDimmed ? 'opacity-10 scale-90 blur-sm' : 'bg-white text-stone-800 border-stone-100 hover:border-stone-400 active:scale-95'}
                `}
              >
                {opt}
              </button>
            );
          })}
        </div>

        <div className="h-24 mt-8 flex items-center justify-center">
          {selected && (
            <p className="text-2xl font-serif-premium italic text-stone-700 animate-in fade-in duration-1000">
              "A thoughtful connection."
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default WordAssociation;
