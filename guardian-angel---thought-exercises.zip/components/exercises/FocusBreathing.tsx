
import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';

interface FocusBreathingProps {
  onComplete: () => void;
  active: boolean;
  onBack?: () => void;
}

const FocusBreathing: React.FC<FocusBreathingProps> = ({ onComplete, active, onBack }) => {
  const [cycle, setCycle] = useState(0);
  const [phase, setPhase] = useState<'Inhale...' | 'Hold' | 'Exhale...'>('Inhale...');
  const [isExpanding, setIsExpanding] = useState(false);

  useEffect(() => {
    if (active) {
      let currentCycle = 0;
      const runCycle = async () => {
        while (currentCycle < 3) {
          setPhase('Inhale...');
          setIsExpanding(true);
          // Haptic Feedback for Start (conceptual)
          if ('vibrate' in navigator) navigator.vibrate(50);
          await new Promise(r => setTimeout(r, 4000));
          
          setPhase('Hold');
          await new Promise(r => setTimeout(r, 2000));
          
          setPhase('Exhale...');
          setIsExpanding(false);
          if ('vibrate' in navigator) navigator.vibrate([30, 50, 30]);
          await new Promise(r => setTimeout(r, 4000));
          
          currentCycle++;
          setCycle(currentCycle);
        }
        onComplete();
      };
      runCycle();
    }
  }, [active, onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0f172a] overflow-hidden animate-in fade-in duration-1000">
      {/* Deep Atmospheric Gradient Background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#1e293b_0%,_#0f172a_100%)]" />
      
      {/* Subliminal Light Beams */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-500/20 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-teal-500/20 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Subtle Exit Button */}
      <button 
        onClick={onBack}
        className="absolute top-6 right-6 p-4 text-white/30 hover:text-white/60 transition-colors z-[60]"
      >
        <X size={24} />
      </button>

      <div className="relative flex flex-col items-center justify-center w-full max-w-md px-8 z-10">
        
        {/* Multi-Layered "Lotus" Orb */}
        <div className="relative flex items-center justify-center w-80 h-80 mb-20">
          
          {/* Outer Bloom Circle */}
          <div className={`absolute w-full h-full rounded-full bg-teal-400/10 blur-xl transition-all duration-[4000ms] ease-in-out mix-blend-screen
            ${isExpanding ? 'scale-125 opacity-40' : 'scale-50 opacity-0'}`} 
            style={{ transitionDelay: '400ms' }}
          />

          {/* Middle Glow Circle */}
          <div className={`absolute w-[80%] h-[80%] rounded-full bg-blue-400/20 blur-lg transition-all duration-[4000ms] ease-in-out mix-blend-screen
            ${isExpanding ? 'scale-110 opacity-60' : 'scale-60 opacity-0'}`}
            style={{ transitionDelay: '200ms' }}
          />

          {/* Core Breathing Orb */}
          <div className={`absolute w-40 h-40 rounded-full bg-gradient-to-br from-blue-400 to-teal-500 shadow-[0_0_60px_rgba(56,189,248,0.4)] transition-all duration-[4000ms] ease-in-out
            ${isExpanding ? 'scale-150' : 'scale-75'}`}
          >
             {/* Inner light pulse animation */}
             <div className="absolute inset-0 bg-white/10 rounded-full animate-pulse" />
          </div>
        </div>

        {/* Fading Serif Typography (Ghost Typography) */}
        <div className="text-center h-32 flex flex-col items-center justify-center">
          <h3 className={`font-serif-premium text-5xl italic text-blue-100 transition-opacity duration-1000
            ${phase === 'Hold' ? 'opacity-40' : 'opacity-100'}`}
          >
            {phase}
          </h3>
          
          <div className="mt-12 space-y-4">
            <p className="text-blue-300/40 text-[10px] font-black uppercase tracking-[0.4em]">
              Cycle {Math.min(cycle + 1, 3)} of 3
            </p>
            {/* Progress Pills */}
            <div className="flex gap-2 justify-center">
              {[0, 1, 2].map((i) => (
                <div 
                  key={i} 
                  className={`h-1 rounded-full transition-all duration-700 ${i <= cycle ? 'bg-blue-400 w-8' : 'bg-blue-900/50 w-2'}`} 
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FocusBreathing;
