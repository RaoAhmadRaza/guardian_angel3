
import React, { useState } from 'react';
import { getAIReflection } from '../../services/geminiService';
import { Heart, MessageCircle } from 'lucide-react';

const EMOTIONS = [
  { 
    label: 'At Peace', 
    icon: '🧘', 
    color: 'from-stone-50 to-emerald-50', 
    accent: 'text-emerald-800'
  },
  { 
    label: 'Resting', 
    icon: '🍵', 
    color: 'from-stone-50 to-indigo-50', 
    accent: 'text-indigo-800'
  },
  { 
    label: 'Joyful', 
    icon: '🌸', 
    color: 'from-stone-50 to-rose-50', 
    accent: 'text-rose-800'
  },
  { 
    label: 'Thoughtful', 
    icon: '📜', 
    color: 'from-stone-50 to-amber-50', 
    accent: 'text-amber-800'
  },
];

interface EmotionalReflectionProps {
  onComplete: () => void;
  active: boolean;
}

const EmotionalReflection: React.FC<EmotionalReflectionProps> = ({ onComplete, active }) => {
  const [selected, setSelected] = useState<string | null>(null);
  const [reflection, setReflection] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [bgGradient, setBgGradient] = useState('from-stone-50 to-stone-100');

  const handleSelect = async (emotion: string) => {
    const emotionData = EMOTIONS.find(e => e.label === emotion);
    if (emotionData) {
      setBgGradient(emotionData.color);
    }
    setSelected(emotion);
    setLoading(true);
    const text = await getAIReflection(emotion);
    setReflection(text);
    setLoading(false);
  };

  const selectedEmotion = EMOTIONS.find(e => e.label === selected);

  return (
    <div className={`fixed inset-0 flex flex-col items-center justify-center transition-all duration-1000 bg-gradient-to-br ${bgGradient}`}>
      
      <div className="relative z-10 w-full max-w-lg px-8 flex flex-col items-center">
        {!selected ? (
          <div className="w-full animate-in fade-in duration-1000">
            <div className="text-center mb-16">
              <span className="text-xs font-black text-stone-400 uppercase tracking-widest mb-4 block">Morning Check-in</span>
              <h3 className="font-serif-premium text-5xl text-stone-800 italic">How is your heart today?</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
              {EMOTIONS.map((e) => (
                <button
                  key={e.label}
                  onClick={() => handleSelect(e.label)}
                  className={`
                    group p-10 rounded-[40px] flex items-center gap-8 transition-all duration-500
                    bg-white border-2 border-stone-100 shadow-sm
                    hover:scale-[1.02] hover:border-stone-400 active:scale-95
                  `}
                >
                  <div className="text-5xl">{e.icon}</div>
                  <span className="font-serif-premium text-2xl text-stone-700 italic">{e.label}</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center w-full animate-in fade-in zoom-in duration-1000">
            {/* Large Serene Symbol */}
            <div className="mb-12">
              <div className="text-[120px] drop-shadow-sm opacity-80">{selectedEmotion?.icon}</div>
            </div>

            {loading ? (
              <div className="py-12 flex flex-col items-center">
                <div className="w-12 h-12 border-4 border-stone-200 border-t-stone-800 rounded-full animate-spin mb-4"></div>
                <p className="text-stone-400 font-bold uppercase tracking-widest text-sm">Listening softly...</p>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <div className="bg-white/60 backdrop-blur-xl p-12 rounded-[48px] border-2 border-white shadow-xl mb-12">
                   <p className="font-serif-premium text-3xl text-stone-800 leading-relaxed italic">
                    "{reflection}"
                  </p>
                </div>

                <div className="w-full flex flex-col items-center gap-6">
                  <button
                    onClick={onComplete}
                    className="px-16 py-6 bg-stone-800 text-white rounded-full font-bold text-xl shadow-2xl hover:bg-stone-700 hover:scale-105 transition-all"
                  >
                    Done & Breathe
                  </button>
                  <button className="text-stone-400 font-bold uppercase tracking-widest text-xs flex items-center gap-2 hover:text-stone-600">
                    <MessageCircle size={16} /> Save to Journal?
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default EmotionalReflection;
