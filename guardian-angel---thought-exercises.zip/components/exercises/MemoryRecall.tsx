
import React, { useState, useEffect } from 'react';
import { Check } from 'lucide-react';

const ALL_ITEMS = ['🍎', '📚', '🍵', '🏠', '⌚', '🗝️', '📱', '🧢', '🚲', '🧤'];

// Defined outside of MemoryRecall to fix TypeScript errors with 'key' and 'children' props
interface CardWrapperProps {
  children: React.ReactNode;
  isSelected?: boolean;
  className?: string;
}

const CardWrapper: React.FC<CardWrapperProps> = ({ children, isSelected, className = "" }) => (
  <div 
    className={`
      relative aspect-square bg-white rounded-[32px] flex items-center justify-center text-6xl 
      shadow-sm border-2 transition-all duration-300
      ${isSelected ? 'border-stone-800 bg-stone-50' : 'border-stone-100'}
      ${className}
    `}
  >
    {isSelected && (
      <div className="absolute -top-3 -right-3 bg-stone-800 text-white rounded-full p-2 shadow-lg">
        <Check size={20} strokeWidth={4} />
      </div>
    )}
    {children}
  </div>
);

interface MemoryRecallProps {
  onComplete: () => void;
  active: boolean;
}

const MemoryRecall: React.FC<MemoryRecallProps> = ({ onComplete, active }) => {
  const [phase, setPhase] = useState<'memorize' | 'recall'>('memorize');
  const [targetItems, setTargetItems] = useState<string[]>([]);
  const [choices, setChoices] = useState<string[]>([]);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [timeLeft, setTimeLeft] = useState(7); // Increased time for easier recall

  useEffect(() => {
    if (active) {
      const shuffled = [...ALL_ITEMS].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, 3);
      setTargetItems(selected);
      const others = shuffled.slice(3, 6);
      setChoices([...selected, ...others].sort(() => 0.5 - Math.random()));
    }
  }, [active]);

  useEffect(() => {
    if (active && phase === 'memorize') {
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 0.1) {
            setPhase('recall');
            clearInterval(timer);
            return 0;
          }
          return prev - 0.1;
        });
      }, 100);
      return () => clearInterval(timer);
    }
  }, [active, phase]);

  const handleSelect = (item: string) => {
    if (selectedItems.includes(item)) return;
    const newSelected = [...selectedItems, item];
    setSelectedItems(newSelected);
    if (newSelected.length >= 3) {
      setTimeout(onComplete, 1500);
    }
  };

  return (
    <div className="w-full h-full flex flex-col items-center justify-center bg-[#FCFAF7] relative overflow-hidden">
      <div className="relative z-10 w-full flex flex-col items-center">
        {phase === 'memorize' ? (
          <div className="text-center w-full px-8 animate-in fade-in duration-1000">
            <h3 className="font-serif-premium text-4xl text-stone-800 italic mb-12">Take a moment to remember...</h3>
            
            <div className="max-w-xs mx-auto mb-16 h-3 bg-stone-100 rounded-full overflow-hidden border border-stone-200">
              <div 
                className="h-full bg-stone-800 transition-all duration-100 ease-linear"
                style={{ width: `${(timeLeft / 7) * 100}%` }}
              />
            </div>

            <div className="flex gap-6 justify-center">
              {targetItems.map((item, i) => (
                <CardWrapper key={i} className="w-32 h-32">
                  <span>{item}</span>
                </CardWrapper>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center w-full px-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
            <h3 className="font-serif-premium text-4xl text-stone-800 italic mb-12">Which three did you see?</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-6 max-w-md mx-auto">
              {choices.map((item, i) => (
                <button
                  key={i}
                  onClick={() => handleSelect(item)}
                  disabled={selectedItems.length >= 3}
                  className="w-full focus:outline-none"
                >
                  <CardWrapper isSelected={selectedItems.includes(item)}>
                    <span>{item}</span>
                  </CardWrapper>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MemoryRecall;
