
import React, { useState, useEffect } from 'react';
import { Timer, Trophy, Flame, ChevronLeft } from 'lucide-react';

const SHAPES = [
  'M 50 20 L 80 80 L 20 80 Z', // Triangle
  'M 20 20 L 80 20 L 80 80 L 20 80 Z', // Square
  'M 50 20 A 30 30 0 1 1 50 80 A 30 30 0 1 1 50 20', // Circle
  'M 50 20 L 90 50 L 50 80 L 10 50 Z', // Diamond
];

interface PatternMatchProps {
  onComplete: () => void;
  active: boolean;
  onBack?: () => void;
}

const PatternMatch: React.FC<PatternMatchProps> = ({ onComplete, active, onBack }) => {
  const [items, setItems] = useState<{ id: number; path: string; isOdd: boolean; rotation: number }[]>([]);
  const [feedback, setFeedback] = useState<number | null>(null);
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    if (active) {
      const baseShape = SHAPES[Math.floor(Math.random() * SHAPES.length)];
      const oddIndex = Math.floor(Math.random() * 6);
      const newItems = Array.from({ length: 6 }).map((_, i) => ({
        id: i,
        path: baseShape,
        isOdd: i === oddIndex,
        // The "odd" one is rotated differently
        rotation: i === oddIndex ? 45 : 0,
      }));
      setItems(newItems);

      const interval = setInterval(() => {
        setSeconds(s => s + 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [active]);

  const handleSelect = (index: number) => {
    if (feedback !== null) return;
    setFeedback(index);
    setTimeout(() => {
      onComplete();
    }, 1500);
  };

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full h-full flex flex-col items-center bg-[#F0F2F5] relative overflow-hidden">
      {/* Radial Focus Glow Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-[600px] bg-white opacity-40 blur-[120px] rounded-full"></div>
      </div>

      {/* HUD: Floating Glass Status Bar */}
      <header className="w-full px-6 py-6 flex items-center justify-between relative z-20">
        <button 
          onClick={onBack}
          className="w-10 h-10 flex items-center justify-center bg-white/60 backdrop-blur-md rounded-full shadow-sm border border-white/40 text-slate-600 active:scale-90 transition-transform"
        >
          <ChevronLeft size={20} />
        </button>

        <div className="flex gap-2">
          <div className="bg-white/60 backdrop-blur-md px-4 py-2 rounded-full shadow-sm border border-white/40 flex items-center gap-2">
            <Timer size={16} className="text-slate-500" />
            <span className="text-sm font-black text-slate-700 font-mono">{formatTime(seconds)}</span>
          </div>
          <div className="bg-white/60 backdrop-blur-md px-4 py-2 rounded-full shadow-sm border border-white/40 flex items-center gap-2">
            <Flame size={16} className="text-orange-500 fill-orange-500" />
            <span className="text-sm font-black text-slate-700 uppercase tracking-tighter">Round 1/1</span>
          </div>
        </div>
        
        <div className="w-10"></div>
      </header>

      <div className="flex-1 flex flex-col items-center justify-center w-full px-8 relative z-10">
        <h3 className="text-2xl font-black mb-10 text-slate-800 tracking-tight text-center">
          Spot the odd shape
        </h3>

        {/* 3D "Squircle" Buttons Grid */}
        <div className="grid grid-cols-2 gap-6 w-full max-w-[320px]">
          {items.map((item, i) => (
            <button
              key={i}
              disabled={feedback !== null}
              onClick={() => handleSelect(i)}
              className={`
                relative aspect-square p-6 rounded-[28px] transition-all duration-150 flex items-center justify-center 
                ${feedback === i ? 'translate-y-[4px]' : 'hover:-translate-y-[2px] active:translate-y-[4px]'}
                ${feedback === i && item.isOdd ? 'bg-green-50' : 
                  feedback === i && !item.isOdd ? 'bg-rose-50' : 
                  feedback !== null && item.isOdd ? 'bg-green-50/50' : 'bg-white'}
              `}
              style={{
                boxShadow: feedback === i 
                  ? 'none' 
                  : '0 8px 24px rgba(0,0,0,0.06), 0 4px 0px #E2E8F0',
                border: feedback === i && item.isOdd ? '3px solid #22C55E' : 
                        feedback === i && !item.isOdd ? '3px solid #F43F5E' : 
                        feedback !== null && item.isOdd ? '3px solid #86EFAC' : '1px solid #F1F5F9'
              }}
            >
              <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-md transition-transform duration-500 ease-out" style={{ transform: `rotate(${item.rotation}deg)` }}>
                <defs>
                  <linearGradient id={`grad-${i}`} x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#4F46E5" />
                    <stop offset="100%" stopColor="#9333EA" />
                  </linearGradient>
                  <filter id={`inset-shadow-${i}`}>
                    <feOffset dx="0" dy="2" />
                    <feGaussianBlur stdDeviation="2" result="offset-blur" />
                    <feComposite operator="out" in="SourceGraphic" in2="offset-blur" result="inverse" />
                    <feFlood floodColor="black" floodOpacity="0.2" result="color" />
                    <feComposite operator="in" in="color" in2="inverse" result="shadow" />
                    <feComposite operator="over" in="shadow" in2="SourceGraphic" />
                  </filter>
                </defs>
                <path 
                  d={item.path} 
                  fill={`url(#grad-${i})`} 
                  filter={`url(#inset-shadow-${i})`}
                />
              </svg>
            </button>
          ))}
        </div>

        {feedback !== null && (
          <div className="mt-12 text-xl font-black animate-in fade-in slide-in-from-top-4 duration-500">
            {items[feedback].isOdd ? (
              <div className="text-green-600 flex items-center gap-2">
                 <Trophy size={24} className="fill-green-600" />
                 Great Vision!
              </div>
            ) : (
              <div className="text-slate-500">There it is. Keep going!</div>
            )}
          </div>
        )}
      </div>

      <div className="h-20 shrink-0"></div>
    </div>
  );
};

export default PatternMatch;
