
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAIWordAssociation = async (baseWord: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Provide 4 calm, positive words associated with '${baseWord}'.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Error:", error);
    return ["Peace", "Calm", "Nature", "Soft"]; // Fallback
  }
};

export const getAIReflection = async (emotion: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `The user feels '${emotion}'. Provide a very short (1 sentence), calming, and reassuring reflection.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            message: { type: Type.STRING }
          },
          required: ["message"]
        }
      }
    });
    return JSON.parse(response.text).message;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "It's okay to feel that way. Take your time."; // Fallback
  }
};
