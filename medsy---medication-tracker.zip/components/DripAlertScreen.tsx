
import React, { useState, useEffect, useMemo } from 'react';
import { ChevronLeft, Activity, Clock, Gauge, AlertCircle } from 'lucide-react';

interface DripAlertScreenProps {
  onBack: () => void;
  // In a real app we'd pass the specific active medication ID
}

const DripAlertScreen: React.FC<DripAlertScreenProps> = ({ onBack }) => {
  const [isStopped, setIsStopped] = useState(false);
  const [now, setNow] = useState(Date.now());
  
  // Mock active infusion data (would come from state in real app)
  const infusion = {
    name: "Normal Saline",
    totalVolume: 500,
    durationMinutes: 120,
    startTime: Date.now() - 30 * 60000, // started 30 mins ago
    alertThreshold: 10
  };

  useEffect(() => {
    if (isStopped) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [isStopped]);

  const stats = useMemo(() => {
    const elapsedMs = now - infusion.startTime;
    const totalMs = infusion.durationMinutes * 60000;
    const progress = Math.min(1, elapsedMs / totalMs);
    const remainingMins = Math.max(0, Math.floor((totalMs - elapsedMs) / 60000));
    const volumeLeft = Math.max(0, Math.floor(infusion.totalVolume * (1 - progress)));
    const flowRate = Math.floor(infusion.totalVolume / (infusion.durationMinutes / 60));

    return { progress, remainingMins, volumeLeft, flowRate };
  }, [now, infusion]);

  const isNearingEnd = stats.remainingMins <= infusion.alertThreshold;

  return (
    <div className="h-full bg-[#FDFDFD] flex flex-col pt-12 overflow-hidden">
      <header className="px-6 flex items-center space-x-4 py-4">
        <button onClick={onBack} className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#0F172A] border border-[#E2E8F0] shadow-sm active:bg-[#F8FAFC]">
          <ChevronLeft size={28} strokeWidth={3} />
        </button>
        <h1 className="text-2xl font-black text-[#0F172A]">Infusion Live</h1>
      </header>

      <div className="flex-1 overflow-y-auto no-scrollbar px-6 py-4 space-y-8 pb-40">
        
        {/* Progress Container */}
        <div className="relative w-full h-80 bg-white rounded-[48px] border border-[#E2E8F0] shadow-card flex flex-col items-center justify-center overflow-hidden">
          {/* Animated Background Pulse for Warning */}
          {isNearingEnd && !isStopped && (
            <div className="absolute inset-0 bg-[#DC2626]/5 animate-pulse" />
          )}

          <div className={`relative transition-all duration-500 ${!isStopped ? 'scale-110' : 'scale-90 opacity-50'}`}>
             <div className="w-32 h-48 bg-[#F5F5F7] rounded-b-3xl rounded-t-lg border-2 border-[#E2E8F0] shadow-lg relative overflow-hidden">
                <div 
                  className={`absolute bottom-0 left-0 right-0 transition-all duration-1000 ${isNearingEnd ? 'bg-[#DC2626]/30' : 'bg-[#2563EB]/20'}`}
                  style={{ height: `${(1 - stats.progress) * 100}%` }}
                />
             </div>
             {!isStopped && (
               <div className={`absolute top-full left-1/2 -translate-x-1/2 w-4 h-4 rounded-full animate-bounce mt-2 ${isNearingEnd ? 'bg-[#DC2626]' : 'bg-[#2563EB]'}`} />
             )}
          </div>

          <div className={`mt-8 px-6 py-2 rounded-2xl flex items-center space-x-3 border-2 font-black uppercase tracking-widest ${!isStopped ? (isNearingEnd ? 'bg-[#FEF2F2] border-[#FEE2E2] text-[#DC2626]' : 'bg-[#ECFDF5] border-[#D1FAE5] text-[#059669]') : 'bg-gray-100 border-gray-200 text-gray-400'}`}>
            <Activity size={20} strokeWidth={3} className={!isStopped ? 'animate-pulse' : ''} />
            <span>{isStopped ? 'Stopped' : (isNearingEnd ? 'Check Soon' : 'Active Flow')}</span>
          </div>
        </div>

        {/* Large Data Points */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-[#0F172A] text-white p-8 rounded-[40px] shadow-card text-center border border-[#1E293B]">
            <Gauge size={28} className="mx-auto mb-2 text-[#60A5FA]" strokeWidth={3} />
            <p className="text-white/50 font-bold uppercase text-[10px] tracking-widest">Rate</p>
            <p className="text-3xl font-black mt-1">{stats.flowRate}ml/hr</p>
          </div>
          <div className={`p-8 rounded-[40px] shadow-card text-center border ${isNearingEnd ? 'bg-[#DC2626] text-white border-[#B91C1C]' : 'bg-white text-[#0F172A] border-[#E2E8F0]'}`}>
            <Clock size={28} className={`mx-auto mb-2 ${isNearingEnd ? 'text-white' : 'text-[#2563EB]'}`} strokeWidth={3} />
            <p className={`${isNearingEnd ? 'text-white/60' : 'text-[#64748B]'} font-bold uppercase text-[10px] tracking-widest`}>Time Left</p>
            <p className="text-3xl font-black mt-1">{stats.remainingMins} Min</p>
          </div>
        </div>

        {/* Dynamic Instructional Alert */}
        <div className={`${isNearingEnd ? 'bg-[#FEF2F2] border-[#FEE2E2]' : 'bg-[#FFFBEB] border-[#FEF3C7]'} border p-6 rounded-[32px] flex items-start space-x-4 shadow-sm`}>
          <AlertCircle className={isNearingEnd ? 'text-[#DC2626]' : 'text-[#D97706]'} size={32} strokeWidth={3} />
          <div className="flex-1">
            <p className={`text-lg font-bold leading-tight ${isNearingEnd ? 'text-[#991B1B]' : 'text-[#92400E]'}`}>
              {isNearingEnd ? `Attention: Only ${stats.remainingMins} minutes left. Please prepare to replace or stop the infusion.` : 'Check the tube for kinks every 30 minutes for patient safety.'}
            </p>
          </div>
        </div>
      </div>

      <section className="absolute bottom-0 left-0 right-0 p-6 bg-white border-t border-[#E2E8F0] shadow-[0_-10px_30px_rgba(0,0,0,0.03)]">
        <button 
          onClick={() => setIsStopped(!isStopped)}
          className={`w-full h-24 rounded-[32px] font-black text-2xl uppercase tracking-[0.1em] shadow-card transition-all active:scale-95 ${!isStopped ? 'bg-[#DC2626] text-white' : 'bg-[#059669] text-white'}`}
        >
          {isStopped ? 'RESUME FLOW' : 'EMERGENCY STOP'}
        </button>
      </section>
    </div>
  );
};

export default DripAlertScreen;
