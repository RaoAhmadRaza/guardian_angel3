
import React from 'react';
import { X, User, Users, Stethoscope, Languages, Phone, LogOut, ChevronRight, ShieldCheck } from 'lucide-react';

interface ProfileSheetProps {
  isOpen: boolean;
  onClose: () => void;
}

const ProfileSheet: React.FC<ProfileSheetProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="absolute inset-0 z-[100] flex flex-col justify-end">
      {/* Semantic Overlay */}
      <div className="absolute inset-0 bg-[#0F172A]/40 backdrop-blur-[4px]" onClick={onClose} />
      
      {/* Sheet Surface */}
      <div className="relative bg-[#FFFFFF] rounded-t-[48px] w-full max-h-[92%] overflow-y-auto animate-in slide-in-from-bottom duration-500 shadow-2xl no-scrollbar border-t border-[#E2E8F0]">
        {/* Handle */}
        <div className="w-full flex justify-center py-4" onClick={onClose}>
          <div className="w-12 h-1.5 bg-[#E2E8F0] rounded-full" />
        </div>

        <div className="px-6 pb-10">
          {/* Profile Card using surface-primary and text-primary */}
          <div className="bg-white rounded-[40px] p-8 shadow-card border border-[#E2E8F0] flex flex-col items-center relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4">
              <div className="bg-[#ECFDF5] text-[#059669] px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center space-x-1 border border-[#D1FAE5]">
                <div className="w-1.5 h-1.5 bg-[#059669] rounded-full animate-pulse" />
                <span>Verified</span>
              </div>
            </div>
            
            <div className="relative">
              <div className="w-28 h-28 rounded-[38px] overflow-hidden shadow-lg border-4 border-[#F5F5F7]">
                <img 
                  src="https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=200&h=200" 
                  className="w-full h-full object-cover"
                  alt="User Avatar"
                />
              </div>
              <div className="absolute -bottom-2 -right-2 bg-[#0F172A] p-2.5 rounded-2xl text-white shadow-lg border-2 border-white">
                <ShieldCheck size={18} strokeWidth={2.5} />
              </div>
            </div>
            
            <h2 className="mt-5 text-2xl font-black text-[#0F172A] tracking-tight">Jacob Miller</h2>
            <div className="mt-1 flex items-center space-x-2">
              <span className="bg-[#F5F5F7] text-[#64748B] px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-widest border border-[#E2E8F0]">
                Patient ID: #84920
              </span>
            </div>
          </div>

          {/* List Items with Design Tokens */}
          <div className="mt-8 overflow-hidden rounded-[32px] bg-white border border-[#E2E8F0] shadow-sm">
            <div className="p-2 space-y-0.5">
               <ProfileListItem 
                icon={<Users size={18} />} 
                label="Caregivers" 
                value="Emily Miller (Primary)" 
               />
               <ProfileListItem 
                icon={<Stethoscope size={18} />} 
                label="Linked Doctors" 
                value="Dr. Aris Thorne, MD" 
               />
               <ProfileListItem 
                icon={<Languages size={18} />} 
                label="Primary Language" 
                value="English (United States)" 
               />
               <ProfileListItem 
                icon={<Phone size={18} />} 
                label="Emergency Contact" 
                value="+1 (555) 012-3456" 
                isLast
               />
            </div>
          </div>

          <div className="mt-10 space-y-6">
            <button className="w-full h-16 flex items-center justify-center space-x-3 rounded-[24px] bg-[#FEF2F2] text-[#DC2626] font-black text-sm uppercase tracking-widest active:scale-[0.97] border border-[#FEE2E2]">
              <LogOut size={20} strokeWidth={2.5} />
              <span>Log out</span>
            </button>
            
            <div className="text-center space-y-1 opacity-50">
              <p className="text-[10px] font-bold text-[#64748B] uppercase tracking-widest">
                Data is end-to-end encrypted
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ProfileListItem = ({ icon, label, value, isLast }: any) => (
  <button className={`w-full flex items-center justify-between p-5 rounded-[24px] hover:bg-[#F8FAFC] active:scale-[0.99] transition-all group ${!isLast ? 'border-b border-[#F1F5F9]' : ''}`}>
    <div className="flex items-center space-x-5">
      <div className="w-11 h-11 bg-[#F5F5F7] rounded-2xl flex items-center justify-center text-[#475569] border border-[#E2E8F0] transition-transform group-active:scale-90 shadow-sm">
        {React.cloneElement(icon as any, { strokeWidth: 2.5 })}
      </div>
      <div className="text-left">
        <p className="text-[9px] font-black text-[#94A3B8] uppercase tracking-[0.2em] mb-0.5 leading-none">
          {label}
        </p>
        <p className="text-base font-bold text-[#0F172A] leading-tight">
          {value}
        </p>
      </div>
    </div>
    <ChevronRight size={18} className="text-[#94A3B8] transition-transform group-hover:translate-x-1" />
  </button>
);

export default ProfileSheet;