
import React, { useState } from 'react';
import { X, ChevronRight, Pill, Droplets, Syringe, Clock, Check, Box, AlertTriangle } from 'lucide-react';
import { Medication, MedicationType } from '../types';

interface AddMedicationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (med: Medication) => void;
}

const steps = ["Label", "Dosage", "Stock", "Review"];

const AddMedicationModal: React.FC<AddMedicationModalProps> = ({ isOpen, onClose, onSave }) => {
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    type: 'pill' as MedicationType,
    dosage: '',
    time: '08:00',
    instructions: 'As directed',
    volumeML: 500,
    durationMinutes: 120,
    alertThreshold: 10,
    initialStock: 30,
    lowStockLevel: 5
  });

  if (!isOpen) return null;

  const handleNext = () => {
    if (step < steps.length - 1) setStep(step + 1);
    else {
      const isInfusion = formData.type === 'infusion';
      const newMed: Medication = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.name,
        dosage: isInfusion ? `${formData.volumeML}ml` : formData.dosage,
        dailyDosage: isInfusion ? `${formData.volumeML}ml / ${formData.durationMinutes}m` : 'N/A',
        type: isInfusion ? 'IV Infusion' : 'Medication',
        subType: formData.type,
        instructions: isInfusion ? `Infuse over ${formData.durationMinutes} minutes` : formData.instructions,
        time: formData.time,
        iconType: formData.type === 'pill' ? 'pill' : formData.type === 'infusion' ? 'infusion' : 'bottle',
        schedule: [{ id: 's1', time: formData.time, isCompleted: false }],
        isInfusion: isInfusion,
        totalVolumeML: isInfusion ? formData.volumeML : undefined,
        durationMinutes: isInfusion ? formData.durationMinutes : undefined,
        startTime: isInfusion ? Date.now() : undefined,
        alertThresholdMinutes: isInfusion ? formData.alertThreshold : undefined,
        currentStock: formData.initialStock,
        lowStockThreshold: formData.lowStockLevel
      };
      onSave(newMed);
      setStep(0);
    }
  };

  return (
    <div className="absolute inset-0 z-[110] bg-[#FDFDFD] flex flex-col pt-12 animate-in slide-in-from-bottom duration-400">
      <header className="px-6 flex items-center justify-between pb-6 border-b border-[#E2E8F0]">
        <h2 className="text-[24px] font-bold text-[#0F172A] tracking-tight">Add New</h2>
        <button onClick={onClose} className="w-[44px] h-[44px] bg-[#F5F5F7] rounded-full flex items-center justify-center text-[#0F172A] border border-[#E2E8F0] active:bg-gray-200">
          <X size={24} strokeWidth={3} />
        </button>
      </header>

      {/* Progress Indicators (radius-full) */}
      <div className="px-6 pt-6 flex space-x-2">
        {steps.map((_, i) => (
          <div key={i} className={`h-[5px] flex-1 rounded-full transition-all duration-300 ${i <= step ? 'bg-[#0F172A]' : 'bg-[#E2E8F0]'}`} />
        ))}
      </div>

      <div className="flex-1 px-6 pt-10 overflow-y-auto no-scrollbar pb-32">
        {step === 0 && (
          <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="space-y-4">
              <label className="text-[20px] font-semibold text-[#64748B]">Medicine Name</label>
              <input 
                autoFocus
                type="text" 
                placeholder="e.g. Saline Drip" 
                className="w-full h-20 px-6 bg-white rounded-[24px] border-2 border-[#E2E8F0] focus:border-[#0F172A] outline-none text-[24px] font-bold text-[#0F172A] placeholder-[#94A3B8] shadow-card transition-all"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>
            
            <div className="space-y-4">
              <label className="text-[20px] font-semibold text-[#64748B]">Type</label>
              <div className="grid grid-cols-3 gap-4">
                <TypeCard active={formData.type === 'pill'} onClick={() => setFormData({...formData, type: 'pill'})} icon={<Pill size={32}/>} label="Pill" />
                <TypeCard active={formData.type === 'infusion'} onClick={() => setFormData({...formData, type: 'infusion'})} icon={<Droplets size={32}/>} label="Drip" />
                <TypeCard active={formData.type === 'injection'} onClick={() => setFormData({...formData, type: 'injection'})} icon={<Syringe size={32}/>} label="Shot" />
              </div>
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="space-y-10 animate-in fade-in slide-in-from-right-8 duration-300">
            {formData.type === 'infusion' ? (
              <div className="space-y-10">
                <div className="space-y-4">
                  <label className="text-[20px] font-semibold text-[#64748B]">Total Volume (ml)</label>
                  <div className="flex items-center space-x-4">
                    <AdjustButton onClick={() => setFormData({...formData, volumeML: Math.max(0, formData.volumeML - 50)})}>-</AdjustButton>
                    <div className="flex-1 h-20 bg-white border-2 border-[#E2E8F0] rounded-[24px] flex items-center justify-center text-[28px] font-bold text-[#0F172A] shadow-card">
                      {formData.volumeML} <span className="text-[16px] text-[#94A3B8] ml-2">ml</span>
                    </div>
                    <AdjustButton onClick={() => setFormData({...formData, volumeML: formData.volumeML + 50})}>+</AdjustButton>
                  </div>
                </div>
                <div className="space-y-4">
                  <label className="text-[20px] font-semibold text-[#64748B]">Time Duration (minutes)</label>
                  <div className="flex items-center space-x-4">
                    <AdjustButton onClick={() => setFormData({...formData, durationMinutes: Math.max(1, formData.durationMinutes - 15)})}>-</AdjustButton>
                    <div className="flex-1 h-20 bg-white border-2 border-[#E2E8F0] rounded-[24px] flex items-center justify-center text-[28px] font-bold text-[#0F172A] shadow-card">
                      {formData.durationMinutes} <span className="text-[16px] text-[#94A3B8] ml-2">min</span>
                    </div>
                    <AdjustButton onClick={() => setFormData({...formData, durationMinutes: formData.durationMinutes + 15})}>+</AdjustButton>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-8">
                <div className="space-y-4">
                  <label className="text-[20px] font-semibold text-[#64748B]">Log Time</label>
                  <div className="flex items-center space-x-4 p-6 bg-white border-2 border-[#E2E8F0] rounded-[24px] shadow-card">
                    <Clock className="text-[#2563EB]" size={32} strokeWidth={3} />
                    <input 
                      type="time" 
                      className="bg-transparent outline-none flex-1 text-[28px] font-bold text-[#0F172A]"
                      value={formData.time}
                      onChange={e => setFormData({...formData, time: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-4">
                  <label className="text-[20px] font-semibold text-[#64748B]">Daily Dosage</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 1 Tablet" 
                    className="w-full h-20 px-6 bg-white border-2 border-[#E2E8F0] rounded-[24px] text-[24px] font-bold text-[#0F172A] shadow-card outline-none focus:border-[#0F172A]"
                    value={formData.dosage}
                    onChange={e => setFormData({...formData, dosage: e.target.value})}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {step === 2 && (
          <div className="space-y-10 animate-in fade-in duration-300">
             <div className="bg-[#EFF6FF] p-6 rounded-[24px] border border-[#DBEAFE] flex items-start space-x-4 shadow-sm">
                <Box className="text-[#2563EB] shrink-0" size={28} strokeWidth={3} />
                <p className="font-semibold text-[#1E40AF] text-[16px] leading-snug">Set current stock to get a reminder when it's time to refill.</p>
             </div>
             
             <div className="space-y-4">
                <label className="text-[20px] font-semibold text-[#64748B]">Units Available</label>
                <div className="flex items-center space-x-4">
                  <AdjustButton onClick={() => setFormData({...formData, initialStock: Math.max(0, formData.initialStock - 5)})}>-</AdjustButton>
                  <div className="flex-1 h-20 bg-white border-2 border-[#E2E8F0] rounded-[24px] flex items-center justify-center text-[28px] font-bold text-[#0F172A] shadow-card">
                    {formData.initialStock}
                  </div>
                  <AdjustButton onClick={() => setFormData({...formData, initialStock: formData.initialStock + 5})}>+</AdjustButton>
                </div>
             </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-8 animate-in zoom-in-95 duration-400">
             <div className="w-[84px] h-[84px] bg-[#ECFDF5] text-[#059669] rounded-[28px] mx-auto flex items-center justify-center border-2 border-[#D1FAE5] shadow-card">
               <Check size={48} strokeWidth={4} />
             </div>
             <h3 className="text-[28px] font-bold text-[#0F172A] text-center tracking-tight">Confirm Details</h3>
             
             <div className="w-full bg-white border-2 border-[#E2E8F0] p-8 rounded-[28px] space-y-8 shadow-card">
               <SummaryRow label="Treatment" value={formData.name || 'Untitled'} />
               <div className="grid grid-cols-2 gap-8 pt-6 border-t border-[#F1F5F9]">
                  <SummaryRow label="Amount" value={formData.type === 'infusion' ? `${formData.volumeML}ml` : formData.dosage} />
                  <SummaryRow label="Time" value={formData.type === 'infusion' ? `${formData.durationMinutes}m` : formData.time} />
               </div>
             </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-[#FDFDFD] border-t border-[#E2E8F0] shadow-floating">
        <button 
          onClick={handleNext}
          disabled={step === 0 && !formData.name}
          className="w-full h-[72px] bg-[#0F172A] text-white rounded-[24px] text-[20px] font-bold flex items-center justify-center space-x-3 shadow-card active:scale-[0.98] transition-all disabled:opacity-30"
        >
          <span>{step === steps.length - 1 ? 'Save & Start' : 'Continue'}</span>
          <ChevronRight size={24} strokeWidth={4} />
        </button>
      </div>
    </div>
  );
};

const TypeCard = ({ active, icon, label, onClick }: any) => (
  <button 
    onClick={onClick}
    className={`p-6 rounded-[24px] flex flex-col items-center justify-center space-y-3 border-2 transition-all active:scale-90 ${active ? 'bg-[#0F172A] border-[#0F172A] text-white shadow-card' : 'bg-white border-[#E2E8F0] text-[#94A3B8]'}`}
  >
    {React.cloneElement(icon, { strokeWidth: 3 })}
    <span className="text-[12px] font-bold uppercase tracking-widest">{label}</span>
  </button>
);

const AdjustButton = ({ children, onClick }: any) => (
  <button onClick={onClick} className="w-20 h-20 bg-[#F5F5F7] border-2 border-[#E2E8F0] rounded-[24px] text-[32px] font-bold text-[#0F172A] active:bg-gray-200 transition-colors shadow-sm">
    {children}
  </button>
);

const SummaryRow = ({ label, value }: any) => (
  <div>
    <p className="text-[11px] font-bold text-[#94A3B8] uppercase tracking-[0.2em] mb-1">{label}</p>
    <p className="text-[22px] font-bold text-[#0F172A] leading-tight">{value}</p>
  </div>
);

export default AddMedicationModal;