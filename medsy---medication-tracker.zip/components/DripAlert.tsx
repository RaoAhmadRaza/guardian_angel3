
import React from 'react';
import { Droplets, ChevronRight, AlertCircle } from 'lucide-react';

interface DripAlertProps {
  medicationName: string;
  timeRemaining: string;
  onAction: () => void;
}

const DripAlert: React.FC<DripAlertProps> = ({ medicationName, timeRemaining, onAction }) => {
  return (
    <div 
      onClick={onAction}
      className="bg-[#0F172A] rounded-[24px] p-6 shadow-card flex items-center text-white active:scale-[0.98] transition-all cursor-pointer border border-[#1E293B]"
    >
      <div className="w-[50px] h-[50px] bg-[#2563EB] rounded-[16px] flex items-center justify-center text-white shadow-lg shrink-0 border border-blue-400/30">
        <Droplets size={28} strokeWidth={2.5} className="animate-pulse" />
      </div>

      <div className="flex-1 ml-5">
        <div className="flex items-center space-x-2 mb-1">
          <AlertCircle size={12} className="text-blue-400" />
          <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-blue-400">Infusion Active</span>
        </div>
        <h3 className="text-[20px] font-bold leading-tight tracking-tight">{medicationName}</h3>
        <p className="text-white/60 text-[14px] font-medium">Approx. {timeRemaining} remaining</p>
      </div>

      <div className="w-[40px] h-[40px] rounded-full glass-surface flex items-center justify-center text-white bg-white/10">
        <ChevronRight size={20} strokeWidth={3} />
      </div>
    </div>
  );
};

export default DripAlert;