
import React from 'react';
import { Clock, ChevronRight, Droplets, AlertTriangle, Box } from 'lucide-react';
import { Medication } from '../types';

interface MedicationCardProps {
  medication: Medication;
  onClick: (med: Medication) => void;
}

const MedicationCard: React.FC<MedicationCardProps> = ({ medication, onClick }) => {
  const isLowStock = medication.currentStock !== undefined && 
                     medication.lowStockThreshold !== undefined && 
                     medication.currentStock <= medication.lowStockThreshold;

  return (
    <div 
      onClick={() => onClick(medication)}
      className={`bg-white border rounded-[28px] p-6 flex items-start space-x-4 shadow-card active:bg-gray-50 transition-all cursor-pointer relative ${isLowStock ? 'border-red-100 bg-red-50/20' : 'border-[#E2E8F0]'}`}
    >
      <div className={`w-[56px] h-[56px] rounded-[16px] flex items-center justify-center shrink-0 border border-[#E2E8F0] ${medication.isInfusion ? 'bg-blue-50' : 'bg-[#F5F5F7]'}`}>
        {medication.subType === 'infusion' ? (
          <Droplets size={28} strokeWidth={2.5} className="text-[#2563EB]" />
        ) : (
          <img 
            src={`https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=150&h=150&seed=${medication.id}`} 
            alt="Medicine" 
            className="w-full h-full object-cover rounded-[14px]" 
          />
        )}
      </div>
      
      <div className="flex-1 pr-2">
        <div className="flex items-center space-x-2 mb-1">
          <h3 className="text-[#0F172A] font-bold text-[18px] leading-tight tracking-tight">
            {medication.name}
          </h3>
          {isLowStock && (
            <div className="bg-[#DC2626] p-1 rounded-full text-white animate-pulse">
              <AlertTriangle size={10} strokeWidth={4} />
            </div>
          )}
        </div>
        <p className="text-[#64748B] text-[14px] font-medium leading-tight">
          {medication.dosage} • {medication.instructions}
        </p>
        
        <div className="flex items-center space-x-4 mt-3">
          <div className="flex items-center text-[#2563EB] font-bold text-[12px] uppercase tracking-wider">
            <Clock size={14} strokeWidth={3} className="mr-1.5" />
            <span>{medication.isInfusion ? 'FLOWING' : medication.time}</span>
          </div>
          
          {medication.currentStock !== undefined && (
            <div className={`flex items-center text-[11px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-lg border ${isLowStock ? 'bg-white border-red-200 text-[#DC2626]' : 'bg-gray-100 border-gray-200 text-[#64748B]'}`}>
              <Box size={10} className="mr-1" />
              {medication.currentStock} {medication.subType === 'infusion' ? 'ml' : 'Left'}
            </div>
          )}
        </div>
      </div>

      <div className="self-center text-[#94A3B8]">
        <ChevronRight size={20} strokeWidth={3} />
      </div>
    </div>
  );
};

export default MedicationCard;