
import React from 'react';
import { ChevronLeft, CheckCircle2, XCircle, TrendingUp } from 'lucide-react';

interface HistoryScreenProps {
  onBack: () => void;
}

const HistoryScreen: React.FC<HistoryScreenProps> = ({ onBack }) => {
  return (
    <div className="h-full bg-[#FDFDFD] flex flex-col pt-12">
      <header className="px-6 flex items-center space-x-4 py-4">
        <button onClick={onBack} className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#0F172A] border border-[#E2E8F0] shadow-sm active:bg-[#F8FAFC]">
          <ChevronLeft size={28} strokeWidth={3} />
        </button>
        <h1 className="text-3xl font-black text-[#0F172A]">Your Progress</h1>
      </header>

      <div className="flex-1 overflow-y-auto no-scrollbar px-6 py-4 space-y-8 pb-24">
        
        {/* Progress Summary Card using Slate tokens */}
        <section className="bg-[#0F172A] rounded-[40px] p-8 text-white shadow-card border border-[#1E293B]">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-5xl font-black">92%</h2>
              <p className="text-white/60 font-bold mt-2">Doses taken this week</p>
            </div>
            <div className="w-16 h-16 bg-[#059669] rounded-2xl flex items-center justify-center shadow-lg border border-white/10">
              <TrendingUp size={32} strokeWidth={3} />
            </div>
          </div>

          <div className="flex justify-between items-center bg-white/5 rounded-3xl p-4 border border-white/10 backdrop-blur-md">
             {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => (
              <div key={i} className="flex flex-col items-center space-y-2">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">{day}</span>
                <div className={`w-8 h-8 rounded-full border-2 ${i < 2 ? 'bg-[#34D399] border-[#34D399]' : 'border-white/20'}`}>
                  {i < 2 && <CheckCircle2 size={12} strokeWidth={4} className="text-[#064E3B] mx-auto mt-1" />}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Grouped Logs with high legibility */}
        <div className="space-y-6">
          <HistoryGroup date="Today, March 19" items={[
            { time: "10:00 AM", name: "Detoxil", status: "taken" },
            { time: "12:00 PM", name: "Almagel", status: "missed" }
          ]} />
          
          <HistoryGroup date="Yesterday, March 18" items={[
            { time: "10:00 AM", name: "Detoxil", status: "taken" },
            { time: "12:00 PM", name: "Almagel", status: "taken" }
          ]} />
        </div>
      </div>
    </div>
  );
};

const HistoryGroup = ({ date, items }: { date: string, items: any[] }) => (
  <div className="space-y-4">
    <h3 className="px-2 text-xl font-black text-[#0F172A]">{date}</h3>
    <div className="space-y-3">
      {items.map((item, idx) => (
        <div key={idx} className="bg-white rounded-[32px] p-5 flex items-center border border-[#E2E8F0] shadow-sm">
          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mr-5 ${item.status === 'taken' ? 'bg-[#ECFDF5] text-[#059669]' : 'bg-[#FEF2F2] text-[#DC2626]'}`}>
            {item.status === 'taken' ? <CheckCircle2 size={28} strokeWidth={3} /> : <XCircle size={28} strokeWidth={3} />}
          </div>
          <div className="flex-1">
            <h4 className="text-lg font-black text-[#0F172A]">{item.name}</h4>
            <p className="text-[#64748B] font-bold">Scheduled at {item.time}</p>
          </div>
          <span className={`text-xs font-black uppercase tracking-wider px-3 py-1 rounded-lg ${item.status === 'taken' ? 'bg-[#D1FAE5] text-[#059669]' : 'bg-[#FEE2E2] text-[#DC2626]'}`}>
            {item.status}
          </span>
        </div>
      ))}
    </div>
  </div>
);

export default HistoryScreen;