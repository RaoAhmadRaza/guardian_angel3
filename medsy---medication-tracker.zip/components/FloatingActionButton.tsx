
import React from 'react';
import { Plus } from 'lucide-react';

const FloatingActionButton: React.FC = () => {
  return (
    <button className="w-16 h-16 bg-[#0F172A] rounded-3xl flex items-center justify-center text-white shadow-card hover:bg-black active:scale-90 transition-all duration-300 border-4 border-white">
      <Plus size={32} strokeWidth={4} />
    </button>
  );
};

export default FloatingActionButton;
