
import React, { useState } from 'react';
import { ChevronLeft, Edit3, ClipboardList, Clock, Package } from 'lucide-react';
import { Medication } from '../types';
import ScheduleItem from './ScheduleItem';

interface DetailScreenProps {
  medication: Medication;
  onBack: () => void;
}

const DetailScreen: React.FC<DetailScreenProps> = ({ medication, onBack }) => {
  const [isLogged, setIsLogged] = useState(false);
  const [sliderPos, setSliderPos] = useState(0);

  const handleTouchMove = (e: React.TouchEvent) => {
    if (isLogged) return;
    const touch = e.touches[0];
    const container = e.currentTarget.getBoundingClientRect();
    const pos = Math.max(0, Math.min(1, (touch.clientX - container.left - 40) / (container.width - 100)));
    setSliderPos(pos * 100);
    if (pos > 0.9) {
      setIsLogged(true);
      setSliderPos(100);
    }
  };

  const handleTouchEnd = () => {
    if (!isLogged) setSliderPos(0);
  };

  return (
    <div className="h-full flex flex-col bg-[#FDFDFD] overflow-hidden">
      {/* High Contrast Header */}
      <header className="px-6 flex items-center space-x-4 py-8">
        <button 
          onClick={onBack}
          className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#0F172A] border border-[#E2E8F0] shadow-sm"
        >
          <ChevronLeft size={28} strokeWidth={3} />
        </button>
        <h1 className="text-2xl font-black text-[#0F172A]">Medicine Details</h1>
      </header>

      <div className="flex-1 overflow-y-auto no-scrollbar pb-40 px-6">
        {/* Simple Large Medicine Visual */}
        <section className="flex flex-col items-center mb-8">
          <div className="w-64 h-64 bg-[#F5F5F7] rounded-[64px] border-2 border-[#E2E8F0] flex items-center justify-center shadow-card mb-6 overflow-hidden">
             <img 
               src={`https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=300&h=300&seed=${medication.id}`} 
               alt="Medicine" 
               className="w-full h-full object-cover" 
             />
          </div>
          <div className="text-center">
            <h2 className="text-4xl font-black text-[#0F172A] leading-tight">{medication.name}</h2>
            <p className="text-xl font-bold text-[#475569] mt-2">{medication.dosage} • {medication.instructions}</p>
          </div>
        </section>

        {/* Clear Info Boxes with Slate/Neutral palette */}
        <section className="grid grid-cols-2 gap-4 mb-10">
          <InfoBox icon={<ClipboardList size={24}/>} label="Dose" value={medication.dailyDosage} />
          <InfoBox icon={<Clock size={24}/>} label="Time" value={medication.time} />
          <InfoBox icon={<Package size={24}/>} label="Supply" value="12 Days" />
          <InfoBox icon={<Edit3 size={24}/>} label="Frequency" value="3x a day" />
        </section>

        {/* Timeline Schedule */}
        <section className="mb-10">
          <h3 className="text-2xl font-black text-[#0F172A] mb-6">Today's Schedule</h3>
          <div className="space-y-2">
            {medication.schedule.map((entry, index) => (
              <ScheduleItem 
                key={entry.id} 
                entry={entry} 
                isFirst={index === 0}
                isLast={index === medication.schedule.length - 1}
              />
            ))}
          </div>
        </section>
      </div>

      {/* Tactile Slider for Senior-Friendly Logging */}
      <section className="absolute bottom-0 left-0 right-0 p-6 bg-white border-t border-[#E2E8F0]">
        <div 
          className={`relative h-24 rounded-[32px] p-2 flex items-center overflow-hidden border-2 transition-colors duration-300 ${isLogged ? 'bg-[#059669] border-[#059669]' : 'bg-[#F1F5F9] border-[#E2E8F0]'}`}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <span className={`text-xl font-black uppercase tracking-widest transition-opacity duration-300 ${isLogged ? 'text-white' : 'text-[#64748B]'}`}>
              {isLogged ? 'Dose Logged ✓' : 'Slide to log dose'}
            </span>
          </div>

          {!isLogged && (
            <div 
              className="relative z-10 w-20 h-20 bg-white rounded-[24px] shadow-card flex items-center justify-center text-[#0F172A] border border-[#E2E8F0]"
              style={{ transform: `translateX(${sliderPos * (2.4)}px)` }}
            >
              <ChevronLeft className="rotate-180" size={36} strokeWidth={4} />
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

const InfoBox = ({ icon, label, value }: any) => (
  <div className="bg-white p-6 rounded-[32px] border border-[#E2E8F0] shadow-sm">
    <div className="text-[#2563EB] mb-2">
      {React.cloneElement(icon, { strokeWidth: 3 })}
    </div>
    <p className="text-[#64748B] text-xs font-black uppercase tracking-widest">{label}</p>
    <p className="text-[#0F172A] font-black text-lg">{value}</p>
  </div>
);

export default DetailScreen;