
import React from 'react';
import { ChevronLeft, TrendingUp, Calendar, AlertCircle } from 'lucide-react';

interface DashboardScreenProps {
  onBack: () => void;
}

const DashboardScreen: React.FC<DashboardScreenProps> = ({ onBack }) => {
  return (
    <div className="h-full bg-[#FDFDFD] flex flex-col pt-12">
      <header className="px-6 flex items-center space-x-4 py-4">
        <button onClick={onBack} className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#0F172A] border border-[#E2E8F0] shadow-sm active:bg-[#F8FAFC]">
          <ChevronLeft size={28} strokeWidth={3} />
        </button>
        <h1 className="text-2xl font-black text-[#0F172A]">Weekly Insights</h1>
      </header>

      <div className="flex-1 overflow-y-auto no-scrollbar px-6 py-4 space-y-10 pb-20">
        
        {/* Weekly Adherence Hero Card */}
        <div className="bg-[#0F172A] rounded-[48px] p-8 text-white shadow-card border border-[#1E293B] relative overflow-hidden">
           <div className="absolute top-0 right-0 p-8 opacity-20">
             <TrendingUp size={100} strokeWidth={2} />
           </div>
           <p className="text-white/50 font-black text-xs uppercase tracking-[0.2em] mb-2">Overall Adherence</p>
           <h2 className="text-7xl font-black">94%</h2>
           <p className="text-white/80 font-bold mt-6 text-lg leading-relaxed">
             Great job, Jacob! You only missed <span className="underline decoration-[#34D399] decoration-4">2 doses</span> this month.
           </p>
        </div>

        {/* Clear Stat Grid */}
        <div className="grid grid-cols-2 gap-4">
          <StatCard 
            label="Total Doses" 
            value="48" 
            icon={<Calendar className="text-[#2563EB]"/>} 
            color="bg-[#EFF6FF] border-[#DBEAFE]" 
          />
          <StatCard 
            label="Missed Doses" 
            value="2" 
            icon={<AlertCircle className="text-[#DC2626]"/>} 
            color="bg-[#FEF2F2] border-[#FEE2E2]" 
          />
        </div>

        {/* Highlight Section */}
        <div>
          <h3 className="text-xl font-black text-[#0F172A] mb-6">Health Milestones</h3>
          <div className="space-y-4">
            <InsightItem 
              title="7 Day Streak!" 
              description="You have taken all your medicine on time for the last week. Keep it up!" 
              emoji="⭐"
              active
            />
            <InsightItem 
              title="Routine Master" 
              description="Morning doses are always taken before 10:00 AM. Excellent routine!" 
              emoji="☀️"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, icon, color }: any) => (
  <div className={`${color} border-2 p-8 rounded-[40px] flex flex-col items-center space-y-4 shadow-sm active:scale-95 transition-transform cursor-pointer`}>
    <div className="bg-white w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm border border-gray-100">
      {React.cloneElement(icon, { size: 32, strokeWidth: 3 })}
    </div>
    <div className="text-center">
      <p className="text-4xl font-black text-[#0F172A]">{value}</p>
      <p className="text-xs font-black text-[#64748B] uppercase tracking-widest mt-1">{label}</p>
    </div>
  </div>
);

const InsightItem = ({ title, description, emoji, active }: any) => (
  <div className={`flex items-start space-x-5 p-6 rounded-[32px] border-2 transition-all active:bg-gray-50 ${active ? 'bg-white border-[#0F172A] shadow-md' : 'bg-gray-50 border-transparent'}`}>
    <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-3xl shadow-sm border border-gray-100 shrink-0">
      {emoji}
    </div>
    <div>
      <h4 className="font-black text-[#0F172A] text-lg">{title}</h4>
      <p className="text-[#475569] leading-relaxed mt-1 font-bold">{description}</p>
    </div>
  </div>
);

export default DashboardScreen;
