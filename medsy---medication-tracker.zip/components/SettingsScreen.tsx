
import React from 'react';
import { ChevronLeft, Bell, Accessibility, Lock, Info, Moon, Volume2, ShieldCheck, Heart } from 'lucide-react';

const SettingsGroup: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="space-y-3">
    <h3 className="px-4 text-xs font-black text-[#64748B] uppercase tracking-[0.2em]">{title}</h3>
    <div className="bg-white rounded-[32px] overflow-hidden shadow-sm border border-[#E2E8F0]">
      {children}
    </div>
  </div>
);

const SettingsItem = ({ icon, label, value, isLast }: any) => (
  <button className={`w-full flex items-center justify-between p-6 hover:bg-[#F8FAFC] active:bg-[#F1F5F9] transition-colors group relative`}>
    <div className="flex items-center space-x-4">
      <div className="w-12 h-12 bg-[#F5F5F7] rounded-2xl flex items-center justify-center text-[#475569] border border-[#E2E8F0]">
        {React.cloneElement(icon as any, { strokeWidth: 3 })}
      </div>
      <span className="font-black text-[#0F172A] text-lg tracking-tight">{label}</span>
    </div>
    <div className="flex items-center space-x-2">
      {value && <span className="text-sm font-bold text-[#64748B]">{value}</span>}
      <div className="text-[#94A3B8]">
        <ChevronLeft size={20} strokeWidth={3} className="rotate-180" />
      </div>
    </div>
    {!isLast && <div className="absolute bottom-0 left-[84px] right-0 h-[1px] bg-[#F1F5F9]" />}
  </button>
);

const SettingsToggle = ({ icon, label, defaultChecked, isLast }: any) => (
  <div className="relative w-full flex items-center justify-between p-6 group">
    <div className="flex items-center space-x-4">
      <div className="w-12 h-12 bg-[#F5F5F7] rounded-2xl flex items-center justify-center text-[#475569] border border-[#E2E8F0]">
        {React.cloneElement(icon as any, { strokeWidth: 3 })}
      </div>
      <span className="font-black text-[#0F172A] text-lg tracking-tight">{label}</span>
    </div>
    
    <label className="relative inline-flex items-center cursor-pointer">
      <input type="checkbox" className="sr-only peer" defaultChecked={defaultChecked} />
      <div className="w-14 h-8 bg-[#E2E8F0] peer-focus:outline-none rounded-full peer 
        peer-checked:after:translate-x-full peer-checked:after:border-white 
        after:content-[''] after:absolute after:top-[4px] after:left-[4px] 
        after:bg-white after:rounded-full after:h-6 after:w-6 
        after:transition-all after:duration-300 after:shadow-md
        peer-checked:bg-[#0F172A]
        shadow-inner transition-colors">
      </div>
    </label>
    {!isLast && <div className="absolute bottom-0 left-[84px] right-0 h-[1px] bg-[#F1F5F9]" />}
  </div>
);

interface SettingsScreenProps {
  onBack: () => void;
}

const SettingsScreen: React.FC<SettingsScreenProps> = ({ onBack }) => {
  return (
    <div className="h-full bg-[#FDFDFD] flex flex-col pt-12">
      <header className="px-6 flex items-center space-x-4 py-4">
        <button onClick={onBack} className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#0F172A] border border-[#E2E8F0] shadow-sm">
          <ChevronLeft size={28} strokeWidth={3} />
        </button>
        <h1 className="text-2xl font-black text-[#0F172A]">Settings</h1>
      </header>

      <div className="flex-1 overflow-y-auto no-scrollbar px-6 py-4 space-y-8 pb-12">
        
        <SettingsGroup title="Notifications">
          <SettingsToggle 
            icon={<Bell size={20} />} 
            label="Medication Reminders" 
            defaultChecked 
          />
          <SettingsToggle 
            icon={<Volume2 size={20} />} 
            label="Audio Alerts" 
          />
          <SettingsItem 
            icon={<Volume2 size={20} />} 
            label="Alert Sound" 
            value="Loud & Clear" 
          />
        </SettingsGroup>

        <SettingsGroup title="Ease of Use">
          <SettingsItem 
            icon={<Accessibility size={20} />} 
            label="Text Size" 
            value="Large"
          />
          <SettingsToggle 
            icon={<Moon size={20} />} 
            label="High Contrast" 
          />
          <SettingsItem 
            icon={<ShieldCheck size={20} />} 
            label="Security Lock" 
            isLast
          />
        </SettingsGroup>

        <div className="mt-4 pb-8">
          <div className="bg-white rounded-[40px] p-8 shadow-card border border-[#E2E8F0] flex flex-col items-center text-center space-y-4">
            <div className="w-20 h-20 bg-[#F5F5F7] rounded-3xl flex items-center justify-center text-[#0F172A] shadow-sm border border-[#E2E8F0]">
              <Heart size={40} strokeWidth={3} />
            </div>
            <div>
              <h4 className="text-xl font-black text-[#0F172A]">Medsy Tracker</h4>
              <p className="text-sm font-bold text-[#64748B] mt-1">Version 1.2.0</p>
            </div>
            <p className="text-sm text-[#475569] leading-relaxed font-medium">
              Made with care to help you manage your health with ease.
            </p>
            <button className="text-[#2563EB] text-sm font-black uppercase tracking-widest pt-2">
              Privacy Policy
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsScreen;
