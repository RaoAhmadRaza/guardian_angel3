
import React from 'react';

interface DateItem {
  day: number;
  weekday: string;
  isActive?: boolean;
}

const dates: DateItem[] = [
  { day: 17, weekday: 'Mon' },
  { day: 18, weekday: 'Tue' },
  { day: 19, weekday: 'Wed', isActive: true },
  { day: 20, weekday: 'Thu' },
  { day: 21, weekday: 'Fri' },
  { day: 22, weekday: 'Sat' },
  { day: 23, weekday: 'Sun' },
];

const DateSelector: React.FC = () => {
  return (
    <div className="flex space-x-3 overflow-x-auto no-scrollbar py-4 -mx-6 px-6">
      {dates.map((date) => (
        <div
          key={date.day}
          className={`flex flex-col items-center justify-center min-w-[64px] h-24 rounded-[28px] transition-all duration-300 cursor-pointer select-none ${
            date.isActive
              ? 'bg-[#0F172A] text-white shadow-card scale-105'
              : 'bg-[#FFFFFF] border border-[#E2E8F0] text-[#94A3B8] hover:bg-[#F5F5F7]'
          }`}
        >
          <span className="text-[10px] uppercase font-black tracking-widest mb-1 opacity-70">
            {date.weekday}
          </span>
          <span className={`text-xl font-black ${date.isActive ? 'text-white' : 'text-[#0F172A]'}`}>
            {date.day}
          </span>
          {date.isActive && (
            <div className="mt-2 w-1.5 h-1.5 bg-white rounded-full" />
          )}
        </div>
      ))}
    </div>
  );
};

export default DateSelector;