
import React from 'react';
import { Check } from 'lucide-react';
import { ScheduleEntry } from '../types';

interface ScheduleItemProps {
  entry: ScheduleEntry;
  isFirst?: boolean;
  isLast?: boolean;
}

const ScheduleItem: React.FC<ScheduleItemProps> = ({ entry, isFirst, isLast }) => {
  return (
    <div className="flex items-start group min-h-[80px]">
      <div className="relative flex flex-col items-center mr-6">
        {!isFirst && (
          <div className={`w-[2px] h-6 ${entry.isCompleted ? 'bg-[#059669]' : 'border-l-2 border-dashed border-[#E2E8F0]'}`} />
        )}
        
        <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all duration-300 shadow-sm z-10 ${
          entry.isCompleted 
            ? 'bg-[#059669] border-[#059669] scale-110' 
            : 'border-[#E2E8F0] bg-white'
        }`}>
          {entry.isCompleted ? (
            <Check size={16} strokeWidth={4} className="text-white" />
          ) : (
            <div className="w-2 h-2 rounded-full bg-[#E2E8F0]" />
          )}
        </div>

        {!isLast && (
          <div className={`w-[2px] flex-1 ${entry.isCompleted ? 'bg-[#059669]' : 'border-l-2 border-dashed border-[#E2E8F0]'}`} />
        )}
      </div>

      <div className="flex-1 py-1">
        <div className={`flex flex-col ${entry.isCompleted ? 'opacity-50' : ''}`}>
          <span className={`text-[10px] font-black uppercase tracking-widest mb-0.5 ${entry.isCompleted ? 'text-[#059669]' : 'text-[#94A3B8]'}`}>
            {entry.isCompleted ? 'Taken' : 'Upcoming'}
          </span>
          <h3 className="text-xl font-black text-[#0F172A] leading-none">
            {entry.time}
          </h3>
        </div>
      </div>
      
      <div className="pt-5">
         <span className={`text-sm font-black ${entry.isCompleted ? 'text-[#059669]' : 'text-[#94A3B8]'}`}>
           {entry.isCompleted ? '✓ 10:02 AM' : 'Pending'}
         </span>
      </div>
    </div>
  );
};

export default ScheduleItem;