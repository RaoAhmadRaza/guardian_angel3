
import React, { useState, useMemo, useEffect } from 'react';
import { Settings, LayoutGrid, Clock3, ChevronDown, ShieldCheck, Phone, AlertCircle } from 'lucide-react';
import DateSelector from './DateSelector';
import MedicationCard from './MedicationCard';
import DripAlert from './DripAlert';
import { Medication, Screen } from '../types';

interface HomeScreenProps {
  medications: Medication[];
  onMedicationClick: (med: Medication) => void;
  onSettings: () => void;
  onProfile: () => void;
  onCalendar: () => void;
  onAdd: () => void;
  activeTab?: string;
  onTabChange?: (tab: any) => void;
  onDripAlert?: () => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ 
  medications, 
  onMedicationClick, 
  onSettings, 
  onProfile, 
  onCalendar, 
  onAdd,
  activeTab = 'home',
  onTabChange,
  onDripAlert
}) => {
  const [now, setNow] = useState(Date.now());
  const [isSOSActive, setIsSOSActive] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 10000);
    return () => clearInterval(timer);
  }, []);

  const activeInfusion = useMemo(() => {
    return medications.find(m => m.isInfusion && m.startTime && (m.startTime + (m.durationMinutes || 0) * 60000 > now));
  }, [medications, now]);

  const timeRemainingStr = useMemo(() => {
    if (!activeInfusion || !activeInfusion.startTime) return "";
    const diff = (activeInfusion.startTime + (activeInfusion.durationMinutes || 0) * 60000) - now;
    const mins = Math.max(0, Math.floor(diff / 60000));
    return `${mins}m`;
  }, [activeInfusion, now]);

  const handleSOS = () => {
    setIsSOSActive(true);
    setTimeout(() => setIsSOSActive(false), 3000);
    alert("Alerting Emily Miller (Caregiver)...");
  };

  return (
    <div className="px-5 h-full flex flex-col pt-8 bg-[#FDFDFD] overflow-hidden">
      {/* 1. Global Header Pattern */}
      <header className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4 cursor-pointer" onClick={onProfile}>
          <div className="w-[50px] h-[50px] rounded-full border-2 border-white shadow-card overflow-hidden bg-[#F5F5F7]">
            <img 
              src="https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=120&h=120" 
              alt="Profile" 
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <div className="flex items-center space-x-1 mb-0.5">
              <ShieldCheck size={12} className="text-[#059669]" />
              <p className="text-[#059669] text-[11px] font-bold uppercase tracking-wider">Family Linked</p>
            </div>
            <h1 className="text-[#0F172A] text-[20px] font-semibold leading-none">Jacob Miller</h1>
          </div>
        </div>
        
        <div className="flex space-x-3">
          <button 
            onClick={handleSOS}
            className={`w-[44px] h-[44px] rounded-full flex items-center justify-center transition-all shadow-card ${isSOSActive ? 'bg-[#DC2626]' : 'bg-[#FEF2F2] text-[#DC2626] border border-[#FEE2E2]'}`}
          >
            <Phone size={22} strokeWidth={2.5} />
          </button>
          <button 
            onClick={onSettings}
            className="w-[44px] h-[44px] bg-white rounded-full flex items-center justify-center text-[#475569] border border-[#E2E8F0] shadow-card"
          >
            <Settings size={22} strokeWidth={2.5} />
          </button>
        </div>
      </header>

      {/* Date Selector Section */}
      <section className="mb-6">
        <button onClick={onCalendar} className="flex items-center space-x-2 mb-4">
          <h2 className="text-[24px] font-bold text-[#0F172A] tracking-tight">Today</h2>
          <ChevronDown size={20} className="text-[#2563EB]" strokeWidth={3} />
        </button>
        <DateSelector />
      </section>

      {/* 2. Hero Card Component (Conditional) */}
      {activeInfusion && (
        <div className="mb-6">
          <DripAlert 
            medicationName={activeInfusion.name} 
            timeRemaining={timeRemainingStr} 
            onAction={onDripAlert || (() => {})} 
          />
        </div>
      )}

      {/* 7. Section Container for Medications */}
      <section className="flex-1 overflow-y-auto no-scrollbar pb-32">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-[22px] font-bold text-[#0F172A]">Schedule</h2>
          <span className="text-[14px] font-bold text-[#64748B]">
            {medications.filter(m => !m.schedule[0].isCompleted).length} remaining
          </span>
        </div>
        
        <div className="space-y-4">
          {medications.map(med => (
            <MedicationCard 
              key={med.id}
              medication={med} 
              onClick={onMedicationClick} 
            />
          ))}
          
          <div className="mt-8 p-6 bg-[#F8FAFC] rounded-[28px] border-2 border-dashed border-[#E2E8F0] text-center">
             <AlertCircle className="mx-auto text-[#94A3B8] mb-2" size={32} />
             <p className="text-[#64748B] text-[14px] font-semibold">Caregivers have been notified <br/> of your progress today.</p>
          </div>
        </div>
      </section>

      {/* Floating Bottom Nav */}
      <div className="absolute bottom-6 left-5 right-5 h-[84px] glass-surface rounded-[32px] px-8 flex items-center justify-between z-50 shadow-floating">
        <TabButton 
          active={activeTab === 'dashboard' || activeTab === 'home'} 
          onClick={() => onTabChange?.('home')} 
          icon={<LayoutGrid size={24} />} 
          label="Home"
        />
        
        <button 
          onClick={onAdd}
          className="w-[64px] h-[64px] bg-[#0F172A] rounded-2xl flex items-center justify-center text-white shadow-card -mt-16 active:scale-90 transition-transform border-4 border-white"
        >
          <div className="text-3xl font-bold">+</div>
        </button>
        
        <TabButton 
          active={activeTab === 'history'} 
          onClick={() => onTabChange?.('history')} 
          icon={<Clock3 size={24} />} 
          label="Track"
        />
      </div>
    </div>
  );
};

const TabButton = ({ active, onClick, icon, label }: any) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center space-y-1 transition-all ${active ? 'text-[#0F172A]' : 'text-[#94A3B8]'}`}
  >
    {React.cloneElement(icon, { strokeWidth: 2.5 })}
    <span className="text-[11px] font-bold uppercase tracking-widest">{label}</span>
  </button>
);

export default HomeScreen;