
import React from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface CalendarOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

const CalendarOverlay: React.FC<CalendarOverlayProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const days = Array.from({ length: 31 }, (_, i) => i + 1);
  const weekDays = ["M", "T", "W", "T", "F", "S", "S"];

  return (
    <div className="absolute inset-0 z-[105] bg-[#0F172A]/40 backdrop-blur-sm flex items-start justify-center pt-24 animate-in fade-in duration-200">
      <div className="bg-white w-[92%] rounded-[48px] p-8 shadow-2xl border border-[#E2E8F0] animate-in zoom-in-95 slide-in-from-top-4 duration-300">
        <header className="flex items-center justify-between mb-8">
          <h3 className="text-2xl font-black text-[#0F172A]">March 2024</h3>
          <div className="flex space-x-3">
            <button className="w-12 h-12 flex items-center justify-center bg-[#F5F5F7] rounded-2xl border border-[#E2E8F0] text-[#0F172A]">
              <ChevronLeft size={24} strokeWidth={3}/>
            </button>
            <button className="w-12 h-12 flex items-center justify-center bg-[#F5F5F7] rounded-2xl border border-[#E2E8F0] text-[#0F172A]">
              <ChevronRight size={24} strokeWidth={3}/>
            </button>
            <button onClick={onClose} className="w-12 h-12 flex items-center justify-center bg-[#0F172A] text-white rounded-2xl">
              <X size={24} strokeWidth={3}/>
            </button>
          </div>
        </header>

        <div className="grid grid-cols-7 gap-y-3 text-center">
          {weekDays.map(d => (
            <span key={d} className="text-xs font-black text-[#94A3B8] uppercase tracking-widest mb-4">{d}</span>
          ))}
          {days.map(day => (
            <button 
              key={day}
              onClick={onClose}
              className={`h-12 w-12 flex items-center justify-center rounded-2xl text-lg font-black transition-all mx-auto
                ${day === 19 ? 'bg-[#0F172A] text-white shadow-md' : 'hover:bg-[#F5F5F7] text-[#0F172A]'}
                ${[17, 18, 19, 21].includes(day) ? 'relative' : ''}
              `}
            >
              {day}
              {[17, 18, 19, 21].includes(day) && (
                <div className={`absolute bottom-2 w-1.5 h-1.5 rounded-full ${day === 19 ? 'bg-[#34D399]' : 'bg-[#2563EB]'}`} />
              )}
            </button>
          ))}
        </div>

        <button 
          onClick={onClose}
          className="w-full mt-8 h-20 bg-[#F5F5F7] rounded-[32px] text-[#0F172A] font-black text-xl active:scale-95 transition-transform border-2 border-[#E2E8F0]"
        >
          Close Calendar
        </button>
      </div>
    </div>
  );
};

export default CalendarOverlay;
