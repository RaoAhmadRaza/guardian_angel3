
export type MedicationType = 'pill' | 'liquid' | 'capsule' | 'tablet' | 'syrup' | 'injection' | 'infusion';

export interface ScheduleEntry {
  id: string;
  time: string;
  isCompleted: boolean;
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  dailyDosage: string;
  type: string;
  subType: MedicationType;
  instructions: string;
  time: string;
  iconType: 'pill' | 'bottle' | 'tablet' | 'injection' | 'infusion';
  schedule: ScheduleEntry[];
  // Inventory
  currentStock?: number;
  lowStockThreshold?: number;
  // Infusion specific fields
  isInfusion?: boolean;
  totalVolumeML?: number;
  durationMinutes?: number;
  startTime?: number; // timestamp
  alertThresholdMinutes?: number;
}

export type Screen = 'home' | 'details' | 'settings' | 'dashboard' | 'history' | 'drip-alert';

export interface ProfileData {
  name: string;
  age: number;
  caregivers: string[];
  doctors: string[];
  language: string;
  emergencyContact: string;
}
