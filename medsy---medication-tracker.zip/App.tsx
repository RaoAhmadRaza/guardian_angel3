
import React, { useState, useEffect } from 'react';
import HomeScreen from './components/HomeScreen';
import DetailScreen from './components/DetailScreen';
import SettingsScreen from './components/SettingsScreen';
import DashboardScreen from './components/DashboardScreen';
import HistoryScreen from './components/HistoryScreen';
import DripAlertScreen from './components/DripAlertScreen';
import ProfileSheet from './components/ProfileSheet';
import AddMedicationModal from './components/AddMedicationModal';
import CalendarOverlay from './components/CalendarOverlay';
import { Medication, Screen } from './types';

// Initial Mock Data
const INITIAL_MEDS: Medication[] = [
  {
    id: '1',
    name: 'Detoxil',
    dosage: '20mg',
    dailyDosage: '60 mg',
    type: 'Dietary supplement',
    subType: 'pill',
    instructions: '1 pill, After Breakfast',
    time: '10:00 AM',
    iconType: 'pill',
    schedule: [
      { id: 's1', time: '10:00 AM', isCompleted: true },
      { id: 's2', time: '15:00 PM', isCompleted: false },
      { id: 's3', time: '18:00 PM', isCompleted: false },
    ]
  },
  {
    id: '2',
    name: 'Almagel',
    dosage: '200ml',
    dailyDosage: '400 ml',
    type: 'Antacid',
    subType: 'liquid',
    instructions: '1 spoon, After Lunch',
    time: '12:00 PM',
    iconType: 'bottle',
    schedule: [
      { id: 's4', time: '12:00 PM', isCompleted: false },
      { id: 's5', time: '20:00 PM', isCompleted: false },
    ]
  }
];

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [medications, setMedications] = useState<Medication[]>(INITIAL_MEDS);
  const [selectedMedication, setSelectedMedication] = useState<Medication | null>(null);
  
  // Modals/Overlays state
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  const handleMedicationClick = (med: Medication) => {
    setSelectedMedication(med);
    setCurrentScreen('details');
  };

  const handleBackToHome = () => {
    setCurrentScreen('home');
    setSelectedMedication(null);
  };

  const handleAddMedication = (newMed: Medication) => {
    setMedications([...medications, newMed]);
    setIsAddOpen(false);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'details':
        return selectedMedication ? (
          <DetailScreen medication={selectedMedication} onBack={handleBackToHome} />
        ) : <HomeScreen medications={medications} onMedicationClick={handleMedicationClick} onSettings={() => setCurrentScreen('settings')} onProfile={() => setIsProfileOpen(true)} onCalendar={() => setIsCalendarOpen(true)} onAdd={() => setIsAddOpen(true)} />;
      case 'settings':
        return <SettingsScreen onBack={handleBackToHome} />;
      case 'dashboard':
        return <DashboardScreen onBack={handleBackToHome} />;
      case 'history':
        return <HistoryScreen onBack={handleBackToHome} />;
      case 'drip-alert':
        return <DripAlertScreen onBack={handleBackToHome} />;
      default:
        return (
          <HomeScreen 
            medications={medications} 
            onMedicationClick={handleMedicationClick} 
            onSettings={() => setCurrentScreen('settings')}
            onProfile={() => setIsProfileOpen(true)}
            onCalendar={() => setIsCalendarOpen(true)}
            onAdd={() => setIsAddOpen(true)}
            activeTab={currentScreen}
            onTabChange={(tab: Screen) => setCurrentScreen(tab)}
            onDripAlert={() => setCurrentScreen('drip-alert')}
          />
        );
    }
  };

  return (
    <div className="w-full h-full bg-white relative max-w-[480px] mx-auto shadow-2xl overflow-hidden select-none">
      {/* App Content */}
      <div className="h-full bg-white relative overflow-hidden">
        {renderScreen()}
      </div>

      {/* Overlays (Keep them inside the relative container) */}
      <ProfileSheet isOpen={isProfileOpen} onClose={() => setIsProfileOpen(false)} />
      <AddMedicationModal isOpen={isAddOpen} onClose={() => setIsAddOpen(false)} onSave={handleAddMedication} />
      <CalendarOverlay isOpen={isCalendarOpen} onClose={() => setIsCalendarOpen(false)} />
    </div>
  );
};

export default App;
